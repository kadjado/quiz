<?php
class Logger {
    private static $logFile = 'logs/app.log'; // Chemin du fichier de log

    // Fonction pour enregistrer un message dans le fichier de log
    public static function log($message, $level = "INFO") {
        // On s'assure que le dossier logs existe
        if (!file_exists('logs')) {
            mkdir('logs', 0777, true);
        }

        $timestamp = date("Y-m-d H:i:s"); // Date et heure actuelles
        $logEntry = "[$timestamp] [$level] $message" . PHP_EOL;

        // On ecrit dans le fichier de log
        file_put_contents(self::$logFile, $logEntry, FILE_APPEND);
    }
}

// Capture des erreurs PHP
ini_set("log_errors", 1);
ini_set("error_log", "logs/php_errors.log");

?>
