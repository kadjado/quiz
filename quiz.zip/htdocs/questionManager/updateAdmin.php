<?php
    session_start();
    include_once('connectdb.php');
    include_once('main.php');
    include_once('config_session.php');
    // Vérifier si l'utilisateur est connecté 
 if (!isset($_SESSION['admin_id'])) { 
    // Rediriger vers la page de connexion si non connecté
     header("Location: login.php");
      exit();
     } 
    if(isset($_GET['id']) && !empty($_GET['id'])){
        $id = htmlspecialchars($_GET['id']);
        $manager = new main($db);
        $admins = $manager->getOneAdmin($id);
        $stmt = $db->prepare("SELECT p.name FROM permissions p JOIN admin_permissions ap ON p.id = ap.permission_id WHERE ap.admin_id = :admin_id");
        $stmt->execute(['admin_id' => $id]);
        $permission = $stmt->fetchAll(PDO::FETCH_COLUMN);
    }
    $permissions = $_SESSION['permissions'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        /* Style global */
body {
    font-family: Arial, sans-serif;
    background-image: url("../template/im1.png");
    
}

.container {
    display: flex;
    justify-content: center;
    align-items: center;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    border-radius: 8px;
    padding: 20px;
    width: 90%;
    height: 600px

}
.form{
    padding: 150px;
    
}
form{

}
h1 {
    text-align: center;
    color: #007BFF;
    margin-bottom: 20px;
    font-size: 24px;
}

.seconde-container {
    display: flex;
    flex-direction: row;
}

fieldset {
    border: 1px solid #ddd;
    border-radius: 5px;
    padding: 100px 100px 100px 50px;
}

legend {
    padding: 0 10px;
    font-weight: bold;
    color: #007BFF;
}

.form-group {
    margin-bottom: 15px;
    width: 300px;
}

label {
    font-weight: bold;
    margin-bottom: 5px;
    padding: 0px 0px 0px 0px;
    width: 900px;
    color: white;
    
}

input[type="text"],
input[type="password"],
input[type="email"] {
    width: 100%;
    padding: 10px;
    font-size: 14px;
    border: 1px solid #ccc;
    border-radius: 5px;
    box-sizing: border-box;
}

input[type="checkbox"] {
    margin-right: 10px;
    width: 100px;
    
}

input[type="submit"] {
    background-color: #007BFF;
    color: #fff;
    border: none;
    padding: 10px 15px;
    font-size: 16px;
    border-radius: 5px;
    cursor: pointer;
    transition: background-color 0.3s ease;
}

input[type="submit"]:hover {
    background-color: #0056b3;
}

.form-group:last-child {
    margin-bottom: 0;
}

/* Responsive design */
@media (max-width: 600px) {
    .container {
        padding: 15px;
    }

    h1 {
        font-size: 20px;
    }

    input[type="text"],
    input[type="password"],
    input[type="email"] {
        padding: 8px;
        font-size: 12px;
    }

    input[type="submit"] {
        font-size: 14px;
    }
}
.form-group.user{
    padding-bottom: 10px;
}
.form-group.check{
    padding-bottom: 30px;
}

    </style>
</head>
<body>
<?php if (in_array('update_admin', $permissions)): ?>

    <h1>Ajout d'un utilisateur</h1>
    <div class="container">
        <div class="form">
            <form action="save.php" method="POST" name="formulaire" id="form">
              <div class="seconde-container">
              <fieldset>
                    <legend>Ajout d'un utilisateur</legend>
                    <div class="form-group user">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" placeholder="Nom de l' utilisateur" value="<?=$admins['username']?>" required>
                    </div>
                    <div class="form-group user">
                        <label for="password">Adresse mail</label>
                        <input type="email" name="email" id="email" placeholder="E-mail de l'utilisateur" required value="<?=$admins['email']?>">
                    </div>
                    <div class="form-group user">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" placeholder="Mot de passe de l' utilisateur" required>
                    </div> <div class="form-group user">
                        <label for="confirmPassword">Confirmer le mot de passe :</label>
                        <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirmez le mot de passe" required>
                    </div>

               </fieldset>
               <fieldset>
                    <legend>Permissions sur les questions</legend>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="read_question" >Voir des questions</label>
                        <input type="checkbox" name="permissions[]" value="1" id="read_question" style="margin: 0px 0px 0px 50px" <?php if (in_array('read_question', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="add_question">Ajouter une question</label>
                        <input type="checkbox" name="permissions[]" value="2" id="add_question" style="margin: 0px 0px 0px 50px" <?php if (in_array('add_question', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="update_question">Modifier une question</label>
                        <input type="checkbox" name="permissions[]" value="3" id="update_question" style="margin: 0px 0px 0px 50px"<?php if (in_array('update_question', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="delete_question">Supprimer une question</label>
                        <input type="checkbox" name="permissions[]" value="4" id="delete_question" style="margin: 0px 0px 0px 50px" <?php if (in_array('delete_question', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
               </fieldset>
               <fieldset>
                    <legend>Attribution des droits sur les administrateurs</legend>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="read_admin">Voir les administrateurs</label>
                        <input type="checkbox" name="permissions[]" value="5" id="read_admin" style="margin: 0px 0px 0px 50px" <?php if (in_array('read_admin', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="add_admin">Ajouter un administrateur</label>
                        <input type="checkbox" name="permissions[]" value="6" id="add_admin" style="margin: 0px 0px 0px 50px" <?php if (in_array('add_admin', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="update_admin">Modifier un administrateur</label>
                        <input type="checkbox" name="permissions[]" value="7" id="update_admin" style="margin: 0px 0px 0px 50px" <?php if (in_array('update_admin', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
                    <div class="form-group check" style="display:inline-flex">
                        <label for="delete_admin">Supprimer un administrateur</label>
                        <input type="checkbox" name="permissions[]" value="8" id="delete_admin" style="margin: 0px 0px 0px 50px" <?php if (in_array('delete_admin', $permission)): ?>checked="checked"<?php endif; ?>>
                    </div>
               </fieldset>
              </div>
              
              <a href="dashboard.php" class="btn btn-secondary">Retour<a>
              <input type="hidden" name="validate" value="update_admin">
              <input type="hidden" name="id" value="<?=$admins['id']?>">
              <input type="submit" value="Modifier" name="sub" class="btn btn-primary" translate="no">
            </form>
        </div>
    </div>
    <?php endif;?>
    <?php if (!in_array('update_admin', $permissions)): ?>
        <div class="alert alert-danger" role="alert" style="margin:10px 600px 0px 200px">
            Vous n'avez pas  cette permission. <a href="dashboard.php" class="alert-link">Revenir au Tableau de bord</a>
        </div>
    <?php endif;?>
</body>
</html>