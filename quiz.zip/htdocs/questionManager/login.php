
<?php
session_start();
require_once 'connectdb.php'; // Connexion à la base de données
require_once 'validation.php';
include_once('logger.php');
// Vérifier si le formulaire a été soumis

if (isset($_SESSION['admin_id'])) { 
    // Rediriger vers la page de connexion si non connecté
     header("Location: dashboard.php");
     exit();
     } 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = validateInput($_POST['username']);
    $password = validateInput($_POST['password']);
    $captcha_input = $_POST['captcha'];
    
    if ($captcha_input !== $_SESSION['captcha']) {
        $error = "CAPTCHA incorrect. Veuillez réessayer.";
    } else {

    // Requête pour vérifier l'utilisateur
    $stmt = $db->prepare("SELECT * FROM quiz_admins WHERE username = :username");
    $stmt->bindParam(':username', $username);
    $stmt->execute();
    $admin = $stmt->fetch();
    if ($admin) {
        $current_time = new DateTime();

        // Vérifier si l'utilisateur est bloqué
        if ($admin['lock_until'] && $current_time < new DateTime($admin['lock_until'])) {
            $error = "Votre compte est verrouillé jusqu'à " . $admin['lock_until'] . ".";

        }
        else{
              // Vérifier le mot de passe
        if (password_verify($password, $admin['password'])) {
            // Réinitialiser les tentatives échouées
            $resetStmt = $db->prepare("UPDATE quiz_admins SET failed_attempts = 0, lock_until = NULL WHERE id = :id");
            $resetStmt->bindParam(':id', $admin['id']);
            $resetStmt->execute();
            
            // Charger les permissions
            $stmt = $db->prepare("SELECT p.name FROM permissions p JOIN admin_permissions ap ON p.id = ap.permission_id WHERE ap.admin_id = :admin_id");
            $stmt->execute(['admin_id' => $admin['id']]);
            $permissions = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['username'] = $admin['username'];
            $_SESSION['permissions'] = $permissions;
            Logger::log("Connexion réussie de l'admin : {$admin['username']}", "SUCCESS");

            header("Location: dashboard.php");
        } else {
            // Incrémenter le compteur de tentatives échouées
            Logger::log("Échec de connexion de l'admin: {$admin['username']}", "WARNING");
            $failed_attempts = $admin['failed_attempts'] + 1;
            $lock_until = null;

            if ($failed_attempts >= 5) { // Limite de 5 tentatives
                $lock_time = new DateTime();
                $lock_time->modify('+15 minutes'); // Bloquer pendant 15 minutes
                $lock_until = $lock_time->format('Y-m-d H:i:s');
            }

            $updateStmt = $db->prepare("UPDATE quiz_admins SET failed_attempts = :failed_attempts, lock_until = :lock_until WHERE id = :id");
            $updateStmt->bindParam(':failed_attempts', $failed_attempts);
            $updateStmt->bindParam(':lock_until', $lock_until);
            $updateStmt->bindParam(':id', $admin['id']);
            $updateStmt->execute();

            if ($lock_until) {
                $error = "Trop de tentatives échouées. Votre compte est verrouillé jusqu'à $lock_until.";
            } else {
             $error = "Identifiants incorrects. Il vous reste " . (5 - $failed_attempts) . " tentatives.";
            }
        }
        }

      
    } else {
        $error = "Nom d'utilisateur incorrect.";
    }
} 
}

?><!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <style>
        body {
            background-image: url("../template/im1.png");
        }
        .container{
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .login-form {
            /*background-color: rgba(255,0,0,0.5);*/
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .login-form h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
        }
        .login-form label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            
        }
        .login-form input {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            background : none;
            border: none;
        }
        .login-form button {
            width: 100%;
            padding: 10px;
            background-color: #007BFF;
            color: #fff;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        .login-form button:hover {
            background-color: #0056b3;
        }
        .login-form img {
            display: block;
            margin: 10px auto;
            border-radius: 5px;
        }
        .error {
            color: red;
            font-size: 12px;
            margin-bottom: 10px;
        }
        input{
            
        }
       
        #captcha{
        width: 30%;
        color: white;

      }
      #captch{
        text-align: center;
    }
    #password, #username{
        background: none;
        color: white;
    }
    .captcha-code{
        align-items: center;
        justify-content: center;
        display: flex;
    }
        label{
            color: white;
        }
        #title{
            color: yellow;
            text-align: center;
        }
        @media (max-width: 768px) {
    .container {
        font-family: Arial, sans-serif;
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
        width: 100%;
        padding: 10px;
        background-color: red;
    }
    

    h1 {
        font-size: 1.2em;
    }

    .login-form {
        padding: 15px;
    }

    input, button {
        font-size: 0.9em;
    }
}
    </style>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

</head>
<body>
    <h1 id="title">Bienvenue sur l'interface Administrateur de Quiz !</h1>
    
    <div class="container">
    <form class="login-form" id="loginForm" action="login.php" method="POST">
        <h2>Connexion</h2>
        
        <label for="username">Username</label>
        <input type="text" id="username" name="username" placeholder="Nom d'utiisateur" required>
        <label for="password">Password</label>
        <input type="password" id="password" name="password" placeholder="Mot de passe" required>
        <label for="captcha" id="captch">CAPTCHA</label>
        <img src="captcha.php" alt="CAPTCHA">
        <div class="captcha-code">
            <input type="text" id="captcha" name="captcha" placeholder="Entrez le code" required>
        </div>
        <button type="submit" name="sub">Se connecter</button>
    <?php if (isset($error)) : ?>
        <p style="color: red;"><?php echo $error; ?></p>
    <?php endif; ?>
    </form>

    <script>
        // Validation côté client
        const loginForm = document.getElementById('loginForm');
        const errorDiv = document.getElementById('error');

        loginForm.addEventListener('submit', function (e) {
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value.trim();

            errorDiv.innerText = ''; // Réinitialiser les erreurs

            if (email === '' || password === '') {
                e.preventDefault();
                errorDiv.innerText = 'Tous les champs sont obligatoires.';
                return;
            }

            // Validation de l'email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                e.preventDefault();
                errorDiv.innerText = 'Veuillez entrer une adresse email valide.';
                return;
            }

            // Vérification de la longueur du mot de passe
            if (password.length < 6) {
                e.preventDefault();
                errorDiv.innerText = 'Le mot de passe doit contenir au moins 6 caractères.';
            }
        });
    </script>
    </div>
   
</body>
</html>