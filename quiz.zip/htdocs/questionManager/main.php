<?php
    class main {
        private $db;

        public function __construct(PDO $bd){
            $this->db = $bd;
        }

        public function getAllQuestions(){
            $sql = $this->db->query('SELECT * FROM questions');    
            $questions = $sql->fetchAll();
            return $questions;
        }

        public function getOneQuestion($id){
            $sql = $this->db->prepare('SELECT * FROM questions WHERE id=:id');
            $sql->execute([
                'id' => $id
            ]);

            $question = $sql->fetch(PDO::FETCH_ASSOC);
            return $question;
        }

        public function createQuestion(array $data){
            $req = $this->db->prepare("INSERT INTO questions (question, option1, option2, option3, option4, reponse) VALUES (:question, :option1, :option2, :option3, :option4, :reponse)");
            $req->execute([
                'question'    => $data['question'],
                'option1'     => $data['option1'],
                'option2'     => $data['option2'],
                'option3'     => $data['option3'],
                'option4'     => $data['option4'],
                'reponse'     => $data['reponse']
            ]);
        }

        public function updateQuestion(array $data){

            $req = $this->db->prepare("UPDATE questions SET question=:question, option1=:option1, option2=:option2, option3=:option3, option4=:option4, reponse=:reponse WHERE questions.id=:id"); 
            $req->execute([
                'question'    => $data['question'],
                'option1'     => $data['option1'],
                'option2'     => $data['option2'],
                'option3'     => $data['option3'],
                'option4'     => $data['option4'],
                'reponse'     => $data['reponse'],
                'id'          => $data['id']
            ]);
        }

        public function deleteQuestion($id){
            $req = $this->db->prepare("DELETE fROM questions WHERE questions.id =:id");
            $req->execute([
                'id' => $id
            ]);
        }
        public function getAllAdmins(){
            $sql = $this->db->query('SELECT * FROM quiz_admins');    
            $admins = $sql->fetchAll();
            return $admins;
        }

        public function getOneAdmin($id){
            $sql = $this->db->prepare('SELECT * FROM quiz_admins WHERE id=:id');
            $sql->execute([
                'id' => $id
            ]);

            $admin = $sql->fetch(PDO::FETCH_ASSOC);
            return $admin;
        }

        public function createAdmin(array $data){
            $req = $this->db->prepare("INSERT INTO quiz_admins (username, email, password) VALUES (:username, :email, :password)");
           
            $req->execute([
                'username'    => $data['username'],
                'email'     => $data['email'],
                'password'     => $data['password']
            ]);
        }

        public function updateAdmin(array $data){

            $req = $this->db->prepare("UPDATE quiz_admins as qa SET username=:username, email=:email WHERE qa.id=:id"); 
            $req->execute([
                'username'  => $data['username'],
                'email'     => $data['email'],
                'id'        => $data['id']
            ]);
        }

        public function deleteAdmin($id){
            $req = $this->db->prepare("DELETE fROM quiz_admins as qa WHERE qa.id =:id");
            $req->execute([
                'id' => $id
            ]);
        }

    }
?>
