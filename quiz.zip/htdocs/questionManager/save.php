<?php
    include_once('connectdb.php');
    include_once('main.php');
    include_once('validation.php');

    if(isset($_POST['sub'])){
        $validate = validateInput($_POST['validate']);
        $manager = new main($db);
        switch($validate){
            case 'add_question': //Il s'agit de l'insertion d'une question
                if(isset($_POST['question']) && !empty($_POST['question']) &&
                   isset($_POST['option1']) && !empty($_POST['option1']) && isset($_POST['option2']) && !empty($_POST['option2']) &&
                   isset($_POST['option3']) && !empty($_POST['option3']) && isset($_POST['option4']) && !empty($_POST['option4']) && 
                   (!empty($_POST['check1']) || !empty($_POST['check2'])|| !empty($_POST['check3'])|| !empty($_POST['check4']))
                    
                ){
                    
                    $question = validateInput($_POST['question']);
                    $option1 = validateInput($_POST['option1']);
                    $option2 = validateInput($_POST['option2']);
                    $option3 = validateInput($_POST['option3']);
                    $option4 = validateInput($_POST['option4']);
                    
                    if(isset($_POST['check1'])){
                        $reponse = $option1;
                    }
                    elseif(isset($_POST['check2'])){
                        $reponse = $option2;
                    }
                    elseif(isset($_POST['check3'])){
                        $reponse = $option3;
                    }
                    elseif(isset($_POST['check4'])){
                        $reponse = $option4;
                    }
                    else{
                        echo"vous devez cocher la bonne réponse";
                    }
                    $data = [
                        'question'=> $question,
                        'option1' => $option1,
                        'option2' => $option2,
                        'option3' => $option3,
                        'option4' => $option4,
                        'reponse' => $reponse
                    ];

                    $manager->createQuestion($data);
                    
                    //Rediriger vers le tableau de bord avec un message flash de l'insertion réussi
                    header('location:dashboard.php?message=insertion');
                }else{ //Rediriger vers le tableau de bord avec un message flash de l'insertion échoué
                    echo "l'insertion a échoué";
                }
            break;
            case 'add_admin': //Il s'agit de l'insertion d'un admin
                if(isset($_POST['username']) && !empty($_POST['username']) &&
                   isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['password']) && !empty($_POST['password'])
                    
                ){
                    
                    $username = validateInput($_POST['username']);
                    $email = validateInput($_POST['email']);
                    $password = validateInput($_POST['password']);
                    $permissions = $_POST['permissions'] ?? [];
                    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
                    $data = [
                        'username'=> $username,
                        'email' => $email,
                        'password' => $hashedPassword,
                        'permissions' => $permissions
                    ];
                    $manager->createAdmin($data);
                    $admin_id = $db->lastInsertId();
                    $stmt = $db->prepare("INSERT INTO admin_permissions (admin_id, permission_id) VALUES (:admin_id, :permission_id)");
                    foreach ($permissions as $permission_id) {
                        $stmt->execute(['admin_id' => $admin_id, 'permission_id' => $permission_id]);
                    }
                    //Rediriger vers le tableau de bord avec un message flash de l'insertion réussi
                    header('location:dashboard.php?message=insertion');
                }else{ //Rediriger vers le tableau de bord avec un message flash de l'insertion échoué
                    echo "l'insertion a échoué";
                }
            break;
            case 'update_question': //Il s'agit de la  mise a jour d'une question
                if(isset($_POST['question']) && !empty($_POST['question']) &&
                   isset($_POST['option1']) && !empty($_POST['option1']) && isset($_POST['option2']) && !empty($_POST['option2']) &&
                   isset($_POST['option3']) && !empty($_POST['option3']) && isset($_POST['option4']) && !empty($_POST['option4']) && 
                   (!empty($_POST['check1']) || !empty($_POST['check2'])|| !empty($_POST['check3'])|| !empty($_POST['check4']))
                    
                ){
                    $question = validateInput($_POST['question']);
                    $option1 = validateInput($_POST['option1']);
                    $option2 = validateInput($_POST['option2']);
                    $option3 = validateInput($_POST['option3']);
                    $option4 = validateInput($_POST['option4']);
                    $id = $_POST['id'];

                    if(isset($_POST['check1'])){
                        $reponse = $option1;
                    }
                    elseif(isset($_POST['check2'])){
                        $reponse = $option2;
                    }
                    elseif(isset($_POST['check3'])){
                        $reponse = $option3;
                    }
                    elseif(isset($_POST['check4'])){
                        $reponse = $option4;
                    }
                    else{
                        echo"vous devez cocher la bonne réponse";
                    }
                    $data = [
                        'question'=> $question,
                        'option1' => $option1,
                        'option2' => $option2,
                        'option3' => $option3,
                        'option4' => $option4,
                        'reponse' => $reponse,
                        'id'      => $id
                    ];

                    $manager->updateQuestion($data);
                    //Rediriger vers la page list.php avec un message flash que l'update a réussi

                    header('location:dashboard.php?message=update');
                }else{ //Rediriger vers le formulaire avenc un message flash que l'insertion a échoué
                    echo "On est dans l'update a échoué";
                }
            break;
            case 'update_admin': //Il s'agit de la mise à jour d'un admin
                if(isset($_POST['username']) && !empty($_POST['username']) &&
                isset($_POST['email']) && !empty($_POST['email'])
                ){
                    $username = validateInput($_POST['username']);
                    $email = validateInput($_POST['email']);
                    $id = htmlspecialchars($_POST['id']);
                    $permissions = $_POST['permissions'] ?? [];
                    
                    $data = [
                        'username'=> $username,
                        'email' => $email,
                        'permissions' => $permissions,
                        'id' => $id
                    ];

                    $manager->updateAdmin($data);
                    $stmt = $db->prepare("DELETE FROM admin_permissions    where admin_id=:admin_id");
                    $stmt->execute(['admin_id' => $id]);
                    $stmt = $db->prepare("INSERT INTO admin_permissions (admin_id, permission_id) VALUES (:admin_id, :permission_id)");
                    foreach ($permissions as $permission_id) {
                        $stmt->execute(['admin_id' => $id, 'permission_id' => $permission_id]);
                    }
                    //Rediriger vers la page list.php avec un message flash de la mise jour de l'admin réussi
                    
                    header('location:dashboard.php?message=update');
                }else{ //Rediriger vers le formulaire avec un message flash que l'insertion a échoué
                    echo "On est dans l'update a échoué";
                }
            break;
            case 'delete_question': // Il s'agit d'une suppression
                if(isset($_POST['id']) && !empty($_POST['id'])){
                    $id = validateInput($_POST['id']);
                    
                    $manager->deleteQuestion($id);

                    //Rediriger vers la page list.php avec un message flash que la suppression a réussi
                    header('location:dashboard.php?message=delete');
                }else{
                    echo "On est dans la suppression a échoué";
                }
            break;
            case 'delete_admin': // Il s'agit d'une suppression
                if(isset($_POST['id']) && !empty($_POST['id'])){
                    $id = validateInput($_POST['id']);
                    
                    $manager->deleteAdmin($id);
                    // on supprime aussi ses permissions
                    $stmt = $db->prepare("DELETE FROM admin_permissions WHERE id = :id");
                    $stmt->execute([
                        'id' => $id
                    ]);
                    //Rediriger vers la page list.php avec un message flash que la suppression a réussi
                    header('location:dashboard.php?message=delete');
                }else{
                    echo "On est dans la suppression a échoué";
                }
            break;
            default:  // Retourner a la liste des articles
                echo "On est ailleurs";
    
        }
    }else{
        echo "Erreur";
    }

    
?>