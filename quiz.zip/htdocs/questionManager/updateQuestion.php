<?php
    session_start();
    include_once('connectdb.php');
    include_once('main.php');
    // Vérifier si l'utilisateur est connecté 
 if (!isset($_SESSION['admin_id'])) { 
    // Rediriger vers la page de connexion si non connecté
     header("Location: login.php");
      exit();
     } 
    if(isset($_GET['id']) && !empty($_GET['id'])){
        $id = htmlspecialchars($_GET['id']);
        $manager = new main($db);
        $questions = $manager->getOneQuestion($id);
    }
    $permissions = $_SESSION['permissions'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body{
            background-image: url("../template/im1.png");
        }
   
#fil{
    color: yellow;
}
.form-group{
    margin: 0px 244px 0px 40px;
    padding-bottom: 10px;
    margin: 0px 0px 0px 130px;
}
.bbc{
    display: inline-flex;
}
input[type="text"]{
    
    width: 750px;

}
input[type="checkbox"]{
    margin: 0px 0px 0px 100px;
    width: 100px;
    
}
.container{
    margin: 0px 300px 0px 0px 0px;
}
h1{
    color: yellow;
    text-align: center;
    margin: 100px 0px 0px 50px;
}

    </style>
     <script >
        document.querySelectorAll('.checkbox-group').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        if (this.checked) {
            document.querySelectorAll('.checkbox-group').forEach(otherCheckbox => {
                if (otherCheckbox !== this) {
                    otherCheckbox.checked = false;
                }
            });
        }
    });
});
    </script>
</head>
<body>
    <?php if (in_array('update_question', $permissions)): ?>
    <div class="container">
    <h1>Modifier une Question</h1>
    <form action="save.php" method="post">
            <div class="form-group">
                <label for="question">Question</label>
                <input type="text" class="form-control" id="question" name="question" value="<?=$questions['question']?>" placeholder="Question" required>
            </div>
            <div class="form-group">
                <label for="option1">Option 1</label><br>
                <div class="bbc">
                    <input type="text" class="form-control" id="option1" name="option1" value="<?=$questions['option1']?>" placeholder="Option 1" required>
                    <input type="checkbox" name="check1" class="checkbox-group" <?php if($questions['option1']==$questions['reponse']):?> checked="checked"<?php endif;?>>
                </div>
            </div>
            <div class="form-group">
                <label for="option2">Option 2</label><br>
                <div class="bbc">
                    <input type="text" class="form-control" id="option2" name="option2" value="<?=$questions['option2']?>" placeholder="Option 2" required>
                    <input type="checkbox" name="check2" class="checkbox-group" <?php if($questions['option2']==$questions['reponse']):?> checked="checked"<?php endif;?>>
                </div> 
            </div>
            <div class="form-group">
                <label for="option3">Option 3</label><br>
                <div class="bbc">
                    <input type="text" class="form-control" id="option3" name="option3" value="<?=$questions['option3']?>" placeholder="Option 3" required>
                    <input type="checkbox" name="check3" class="checkbox-group" <?php if($questions['option3']==$questions['reponse']):?> checked="checked"<?php endif;?>>
                </div>
            </div>
            <div class="form-group">
                <label for="option4">Option 4</label><br>
               <div class="bbc">
               <input type="text" class="form-control" id="option4" name="option4" value="<?=$questions['option4']?>" placeholder="Option 4" required>
               <input type="checkbox" name="check4" class="checkbox-group" <?php if($questions['option4']==$questions['reponse']):?> checked="checked"<?php endif;?>>
               </div>
            </div>
            
            <hr>
            <input type="hidden" name="validate" value="update_question">
            <div class="bouton">
                <a href="Dashboard.php" style="" class="btn btn-outline-secondary">Retour</a>
                <input type="submit" value="Modifier" name="sub" class="btn btn-primary" translate="no" style="margin:0px 0px 0px 900px">
            </div>
        </form>
    </div>
    <?php endif;?>
    <?php if (!in_array('update_question', $permissions)): ?>
        <div class="alert alert-danger" role="alert" style="margin:10px 600px 0px 200px">
            Vous n'avez pas le droit d'ajouter une question. <a href="dashboard.php" class="alert-link">Revenir au Tableau de bord</a>
        </div>
        
    <?php endif;?>
    <script >
        document.querySelectorAll('.checkbox-group').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        if (this.checked) {
            document.querySelectorAll('.checkbox-group').forEach(otherCheckbox => {
                if (otherCheckbox !== this) {
                    otherCheckbox.checked = false;
                }
            });
        }
    });
});
    </script> 
</body>
</html>