<?php
    try{
        $db = new PDO("pgsql:host=localhost;port=5432;dbname=quiz_db", 'connect_admin_db2025','adMin_23_01@Ok20#25.');
    }catch (Exception $e){
        die('Erreur de connexion à a Base de Données : '. $e->getMessage());
    }
    
?>