<?php
session_start();
include_once('connectdb.php');

// Vérifier si l'utilisateur est administrateur
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Vérifier si un fichier a été téléchargé
if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {
    $filename = $_FILES['file']['tmp_name'];
    
    // Vérifier l'extension
    $fileExtension = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    if ($fileExtension !== 'csv') {
        die("Erreur : Seuls les fichiers CSV sont autorisés !");
    }

    // Ouvrir le fichier CSV
    $handle = fopen($filename, "r");
    if ($handle === false) {
        die("Erreur lors de l'ouverture du fichier.");
    }

    // Lire et insérer les données
    $db->beginTransaction();
    try {
        while (($data = fgetcsv($handle, 1000, ",", '"', "\\")) !== false) {
            $question = trim($data[0]);
            $option1 = trim($data[1]);
            $option2 = trim($data[2]);
            $option3 = trim($data[3]);
            $option4 = trim($data[4]);
            $reponse = trim($data[5]);

            // Insérer dans la base de données
            $stmt = $db->prepare("INSERT INTO questions (question, option1, option2, option3, option4, reponse) 
                                  VALUES (:question, :option1, :option2, :option3, :option4, :reponse)");
            $stmt->execute([
                ':question' => $question,
                ':option1' => $option1,
                ':option2' => $option2,
                ':option3' => $option3,
                ':option4' => $option4,
                ':reponse' => $reponse
            ]);
        }
        fclose($handle);
        $db->commit();
        header("Location: dashboard.php?message=import");
    } catch (Exception $e) {
        $db->rollBack();
        echo "Erreur : " . $e->getMessage();
    }
} else {
    echo "Erreur lors du téléchargement du fichier.";
}
?>
