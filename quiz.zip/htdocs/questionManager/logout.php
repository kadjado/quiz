<?php
session_start();
include_once("logger.php");
Logger::log("Deconnexion  de l'admin : {$_SESSION['username']}", "WARNING");
session_unset();
session_destroy();



header("Location: dashboard.php");
      exit();
?>