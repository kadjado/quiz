                                        
<?php 
    session_start();
    include_once('connectdb.php');  
    include_once('config_session.php');
    include_once('main.php'); 
    
    if (!isset($_SESSION['admin_id'])) { 
        // Rediriger vers la page de connexion si non connecté
         header("Location: login.php");
          exit();
         }  
    $manager = new main($db);
    $questions = $manager->getAllQuestions();
    $admins = $manager->getAllAdmins();
     // Vérifier si l'utilisateur est connecté 

     $permissions = $_SESSION['permissions'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="../bootstrap/js/bootstrap.bundle.min.js"></script>
    <style>
        
        .logout-btn {
            background-color: #e74c3c;
            color: white;
            border: none;
            padding: 10px 15px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: background-color 0.3s ease;
        }
        .navbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #333;
            color: white;
            padding: 2px 20px 3px 20px;
        }
        .navbar h1 {
            margin: 0;
            font-size: 20px;
        }
        body{
            background-image: url("../template/im1.png");
            overflow: hidden;
            
        }
        .container{
    
        }
        
        .scrol{
            height: 600px;
            overflow-y: auto;
           
        }
        #scroller{
            height: 650px;
        }
        th{
            
            position: sticky;
            top: 0;
            z-index:1;
            height: 10px;
        }
        td{
            background: none;
            
        }
        .tab {
    padding: 5px 20px;
    cursor: pointer;
    border: 1px solid #ccc;
    border-bottom: none;
    background: none;
    margin-right: 5px;
    transition: background 0.3s ease;
    color : white;
}
.tab:hover {
    background: #eaeaea;
}
.tab.active {
    background: none;
    border-bottom: 2px solid white;
    font-weight: bold;
}

/* Contenu des onglets */
.tab-content {
    display: none;
    padding: 15px;
    border: 1px solid #ccc;
    border-top: none;
    background: #fff;
}
.tab-content.active {
    display: block;
    padding: 2px 0px 10px 0px;
    background: none;
    border: none;
}
 .tabs {
    display: flex;
    border-bottom: 2px solid #ccc;
    
 }
 #title{
    text-align: center;
    color: yellow;
 }

    </style>
</head>
<body>
<div class="container">
        <div class="navbar">
        <h1>Tableau de bord</h1>
        
        <form method="POST" action="logout.php" style="margin: 0;">
            <button type="submit" class="btn btn-outline-danger">Déconnexion</button>
        </form>
    </div>
    <?php
            if(isset($_GET['message']) && !empty($_GET['message'])){
                $message = htmlspecialchars($_GET['message']);
                switch($message){
                    case 'insertion':
        ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert" style="height:50px">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            <strong>Well done!</strong> Insertion OK
                        </div>
                    
        <?php
                        break;
                    case 'update':
        ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert" style="height:50px">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            <strong>Well done!</strong> Mise à jour OK
                        </div>
        <?php
                        break;
                    case 'delete':
        ?>
                     <div class="alert alert-danger alert-dismissible fade show" role="alert" style=" height:50px">
                            <strong>Well done!</strong> Suppression Ok
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>>
        <?php
                    break;
                    case 'import':
               
            
        ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert" style="height:50px">
                            <strong>Well done!</strong> Importation Ok
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>>
        <?php
                    break;
            }
        }
?>
    <div class="tabs">
    <?php if (in_array('read_question', $permissions)): ?>
        <div class="tab" onclick="showTab('question')">Voir les question</div>
    <?php endif; ?>
    <div class="tab active" onclick="showTab('home')">Profil</div>
    <?php if (in_array('read_admin', $permissions)): ?>
        <div class="tab" onclick="showTab('admin')">Voir les administrateurs</div>
    <?php endif; ?>
        </div>
        <div id="admin" class="tab-content">
        <h4 id="title">Liste des Administrateurs de quiz</h4>
        <?php if (in_array('add_admin', $permissions)): ?>
            <a href="addAdmin.php" class="btn btn-primary" style="margin: 0px 0px 5px 0px">Ajoutez un administrateur<a>
        <?php endif; ?>
       <div class="scrol">
       <table class="table table-condensed table-striped" id="scroller">
            <tr style="background: white">
                <th style="background-color: lightgray;">N°</th>
                <th style="background-color: lightgray;">Nom d'utilisateur</th>
                <th style="background-color: lightgray;">email</th>
                <th style="background-color: lightgray;">Date d'ajout</th>
            </tr>
           
            <?php
                $i = 1;
                foreach($admins as $admin){
            ?>
                <tr style="color: white" id ="tr">
                    <td style="background: none; color: yellow" ><?= $i ?></td>
                    <td style="background: none; color: white" ><?= $admin['username'] ?></td>
                    <td style="background: none; color: white"><?= $admin['email'] ?></td>
                    <td style="background: none; color: white"><?= $admin['created_at']?></td>
                    <td style="background: none">
                        
                        <div class="inbdl" style="display: block">
                        <?php if (in_array('update_admin', $permissions)): ?>
                            <a href="updateAdmin.php?id=<?=$admin['id']?>" class="btn btn-outline-warning btn-sm">Modifier</a>
                        <?php endif; ?>
                        <?php if (in_array('delete_admin', $permissions)): ?>
                            <form action="save.php" method="post" style="display:inline-block" id="target">
                                <input type="hidden" name="id" value="<?= $admin['id']?>">
                                <input type="hidden" name="validate" value="delete_admin">
                                <input type="submit" name="sub" value="Supprimer" class="btn btn-outline-danger btn-sm" translate="no">
                            </form>
                        <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php
                $i++;
                }
            ?>
    </table>
       </div>
    </div>
    <div id="question" class="tab-content">
       
       <h4 id="title">Liste des Questions</h4>
       <?php if (in_array('add_question', $permissions)): ?>
       <a href="addQuestion.php" class="btn btn-primary" style="margin: 0px 0px 5px 0px">Ajoutez une Question</a>
       <?php endif; ?>
        <div class="scrol">
        <table class="table table-condensed table-striped" id="scroller">
           <tr style="background: white">
               <th style="background-color: lightgray;">N°</th>
               <th style="background-color: lightgray;">Question</th>
               <th style="background-color: lightgray;">Option 1</th>
               <th style="background-color: lightgray;">Option 2</th>
               <th style="background-color: lightgray;">Option 3</th>
               <th style="background-color: lightgray;">Option 4</th>
               <th style="background-color: lightgray;">Réponse</th>
           </tr>
                       <?php
                           $i = 1;
                           foreach($questions as $question){
                       ?>
                       <tr style="color: white" id="tr">
                           <td style="background: none; color: yellow;" ><?= $i ?></td>
                           <td style="background: none; color: white" ><?= $question['question'] ?></td>
                           <td style="background: none; color: white"><?= $question['option1'] ?></td>
                           <td style="background: none; color: white"><?= $question['option2'] ?></td>
                           <td style="background: none; color: white"><?= $question['option3'] ?></td>
                           <td style="background: none; color: white"><?= $question['option4'] ?></td>
                           <td style="background: none; color: green; font-family:bold" ><?= $question['reponse'] ?></td>
                           <td style="background: none">
                               
                               <div class="inbdl" style="display:inline-flex">
                                   <?php if (in_array('update_question', $permissions)): ?>
                                       <a href="updateQuestion.php?id=<?=$question['id']?>" class="btn btn-outline-warning btn-sm">Modifier</a>
                                   <?php endif; ?>
                                   <?php if (in_array('delete_question', $permissions)): ?>
                                       <form action="save.php" method="post" style="display:inline-flex; margin-left:10px" id="target">
                                       <input type="hidden" name="id" value="<?= $question['id']?>">
                                       <input type="hidden" name="validate" value="delete_question">
                                       <input type="submit" name="sub" value="Supprimer" class="btn btn-danger btn-sm" translate="no">
                                   </form>

                                   <?php endif; ?>
                           
                               </div>
                           </td>
                       </tr>
           <?php
               $i++;
               }
           ?>
       </table>
       </div>
       </div>
    </div>
    <script>
        // Fonction pour afficher un onglet
        function showTab(tabId) {
            
            // Masquer tous les contenus 
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(content => content.classList.remove('active'));

            // Désactiver tous les onglets
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));

            // Activer le contenu et l'onglet correspondant
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
    <!--script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script-->
    <script>
        $(function(){
            $( "#target" ).on( "submit", function( event ) {
                if(confirm("Voulez vous supprimer cet enregistrement")){
                    alert("Cet enregistrement va être supprimé")
                }else{
                    event.preventDefault();
                }
            });
        })
    </script>
    
</body>
</html>