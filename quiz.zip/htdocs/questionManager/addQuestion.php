<?php 
    session_start();
    include_once('connectdb.php');  
    include_once('config_session.php');

     // Vérifier si l'utilisateur est connecté 
 if (!isset($_SESSION['admin_id'])) { 
    // Rediriger vers la page de connexion si non connecté
     header("Location: login.php");
      exit();
     } 
     $permissions = $_SESSION['permissions'];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="../bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <title>Document</title>
    <style>
        body{
            background-image: url("../template/im1.png");
        }
        .tabs {
    display: flex;
    margin-bottom: 10px;
    border-bottom: 2px solid #ccc;
    margin: 0px 605px 0px 301px;
    align-items: center;
    justify-content: center;
}
.tab {
    padding: 10px 20px;
    cursor: pointer;
    border: 1px solid #ccc;
    border-bottom: none;
    background: none;
    margin-right: 5px;
    transition: background 0.3s ease;
    color : white;
}
.tab:hover {
    background: #eaeaea;
}
.tab.active {
    background: none;
    border-bottom: 2px solid white;
    font-weight: bold;
}

/* Contenu des onglets */
.tab-content {
    display: none;
    padding: 15px;
    border: 1px solid #ccc;
    border-top: none;
    background: #fff;
}
.tab-content.active {
    display: block;
    padding: 50px 0px 80px 0px;
    background: none;
    border: none;
}
#fil{
    color: yellow;
}
.form-group{
    margin: 0px 244px 0px 40px;
    padding-bottom: 10px;
    margin: 0px 0px 0px 130px;
}
.bbc{
    display: inline-flex;
}
input[type="text"]{
    
    width: 750px;

}
input[type="checkbox"]{
    margin: 0px 0px 0px 100px;
    width: 100px;
    
}
.container{
    margin: 0px 300px 0px 0px 0px;
}

    </style>
   
</head>
<body>
<?php if (in_array('add_question', $permissions)): ?>
    <div class="container">
        <h1>Ajout d'une nouvelle Question</h1>
        <div class="tabs">
            <div class="tab active" onclick="showTab('man')">Ajouter manuellement</div>
            <div class="tab" onclick="showTab('auto')">Charger un fichier</div>
        </div>
        
        <div id="auto" class="tab-content">
            <form action="upload.php" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="file" id="fil">Charger un fichier CSV</label>
                <input type="file" class="form-control" id="file" name="file" accept=".csv" required>
            </div>
            <input type="submit" value="Importer" class="btn btn-success">
            </form>

        </div>
        <div id="man" class="tab-content  active">
        <form action="save.php" method="post">
            <div class="form-group">
                <label for="question">Question</label>
                <input type="text" class="form-control" id="question" name="question" placeholder="Entrez la question" required>
            </div>
            <div class="form-group">
                <label for="option1">Option 1</label><br>
                <div class="bbc">
                    <input type="text" class="form-control" id="option1" name="option1" placeholder="Entrez l'option 1" required>
                    <input type="checkbox" name="check1" id="check1" class="checkbox-group">
                </div>
            </div>
            <div class="form-group">
                <label for="option2">Option 2</label><br>
                <div class="bbc">
                    <input type="text" class="form-control" id="option2" name="option2" placeholder="Entrez l'option 2" required>
                    <input type="checkbox" name="check2" id="check2" class="checkbox-group">
                </div>
            </div>
            <div class="form-group">
                <label for="option3">Option 3</label><br>
              <div class="bbc">
                    <input type="text" class="form-control" id="option3" name="option3" placeholder="Entrez l'option 3" required>
                    <input type="checkbox" name="check3" id="check3" class="checkbox-group">
              </div>
            </div>
            <div class="form-group">
                <label for="option4">Option 4</label><br>
               <div class="bbc">
                    <input type="text" class="form-control" id="option4" name="option4" placeholder="Entrez l'option 4" required>
                    <input type="checkbox" name="check4" id="check4" class="checkbox-group">
               </div>
            </div>
            
            <hr>
            <input type="hidden" name="validate" value="add_question">
            <div class="bouton">
                <a href="Dashboard.php" style="" class="btn btn-outline-secondary">Retour</a>
                <input type="submit" value="Ajouter" name="sub" class="btn btn-primary" translate="no" style="margin:0px 0px 0px 900px">
            </div>
        </form>
        </div>
    </div>
    <?php endif;?>
    <?php if (!in_array('add_question', $permissions)): ?>
        <div class="alert alert-danger" role="alert" style="margin:10px 600px 0px 200px">
            Vous n'avez pas cette permission. <a href="dashboard.php" class="alert-link">Revenir au Tableau de bord</a>
        </div>
    <?php endif;?>
    <script>
        document.querySelectorAll('.checkbox-group').forEach(checkbox => {
            checkbox.addEventListener('change', function() {
                if (this.checked) {
                    document.querySelectorAll('.checkbox-group').forEach(otherCheckbox => {
                        if (otherCheckbox !== this) {
                            otherCheckbox.checked = false;
                        }
                    });
                }
            });
        });
    </script>
    <script>
        // Fonction pour afficher un onglet
        function showTab(tabId) {
            
            // Masquer tous les contenus 
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(content => content.classList.remove('active'));

            // Désactiver tous les onglets
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));

            // Activer le contenu et l'onglet correspondant
            document.getElementById(tabId).classList.add('active');
            event.target.classList.add('active');
        }
    </script>
    
</body>
</html>