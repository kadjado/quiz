<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau avec en-tête fixe</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f0f0;
        }

        .table-container {
            width: 600px;
            height: 300px;
            overflow-y: auto; /* Active le scroll vertical */
            background: white;
            border: 1px solid #ccc;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: center;
        }

        th {
            background-color: lightgray;
            position: sticky;  /* Fixe l'en-tête en haut */
            top: 0;            /* Fixe l'en-tête au sommet du conteneur */
            z-index: 1;        /* Assure que l'en-tête est au-dessus des lignes */
        }

        tbody {
            display: block;
            max-height: 250px; /* Hauteur maximale du corps de table */
            overflow-y: auto;  /* Active le défilement pour les lignes */
        }

        tr {
            display: block;
        }
    </style>
</head>
<body>

    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nom</th>
                    <th>Âge</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>1</td><td>Jean</td><td>30</td></tr>
                <tr><td>2</td><td>Marie</td><td>25</td></tr>
                <tr><td>3</td><td>Luc</td><td>28</td></tr>
                <tr><td>4</td><td>Sophie</td><td>22</td></tr>
                <tr><td>5</td><td>Paul</td><td>35</td></tr>
                <tr><td>6</td><td>Emma</td><td>27</td></tr>
                <tr><td>7</td><td>Antoine</td><td>29</td></tr>
                <tr><td>8</td><td>Laura</td><td>26</td></tr>
                <tr><td>9</td><td>Michel</td><td>40</td></tr>
            </tbody>
        </table>
    </div>

</body>
</html>
