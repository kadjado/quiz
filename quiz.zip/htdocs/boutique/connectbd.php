<?php
    try{
        $bd = new PDO('mysql:host=localhost;dbname=boutique','root', '');
    }catch (Exception $e){
        die('Erreur: '. $e->getMessage());
    }
    
?>