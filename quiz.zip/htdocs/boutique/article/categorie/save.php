<?php
    include_once('../connectbd.php');
    include_once('../articleManager.php');

    if(isset($_POST['validate'])){
        $validate = htmlspecialchars($_POST['validate']);
        $manager = new ArticleManager($bd);
        switch($validate){
            case 'add': //Il s'agit d'une insertion
                if(isset($_POST['libelle']) && !empty($_POST['libelle'])
                ){
                    $libelle = htmlspecialchars($_POST['libelle']);

                    $data = [
                        'libelle'     => $libelle
                    ];

                    $manager->create($data);
                    
                    //Rediriger vers la page list.php avec un message flash que l'insertion a réussi
                    header('location:list.php?message=insertion');
                }else{ //Rediriger vers le formulaire avenc un message flash que l'insertion a échoué
                    echo "On est dans l'insertion a échoué";
                }
            break;
            case 'update': //Il s'agit d'une mise a jour
                if(isset($_POST['libelle']) && !empty($_POST['libelle']) &&
                   isset($_POST['id']) && !empty($_POST['id'])
                ){
                    $libelle = htmlspecialchars($_POST['libelle']);
                    $id = htmlspecialchars($_POST['id']);

                    $data = [
                        'libelle'     => $libelle,
                        'id'          => $id
                    ];

                    $manager->update($data);
                    //Rediriger vers la page list.php avec un message flash que l'update a réussi

                    header('location:list.php?message=update');
                }else{ //Rediriger vers le formulaire avenc un message flash que l'insertion a échoué
                    echo "On est dans l'update a échoué";
                }
            break;
            case 'delete': // Il s'agit d'une suppression
                if(isset($_POST['id']) && !empty($_POST['id'])){
                    $id = htmlspecialchars($_POST['id']);
                    $manager->delete($id);

                    //Rediriger vers la page list.php avec un message flash que la suppression a réussi
                    header('location:list.php?message=delete');
                }else{
                    echo "On est dans la suppression a échoué";
                }
            break;
            default:  // Retourner a la liste des articles
                echo "On est ailleurs";
    
        }
    }else{
        echo "Il manque le validate";
    }

    
?>