<?php    
    include_once('../connectbd.php');  
    include_once('articleManager.php'); 
     
    $manager = new ArticleManager($bd);
    $articles = $manager->getAll();
    //var_dump($articles);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <a href="../index.php">Accueil</a>
        <?php
            if(isset($_GET['message']) && !empty($_GET['message'])){
                $message = htmlspecialchars($_GET['message']);
                switch($message){
                    case 'insertion':
        ?>
                        <div class="alert alert-dismissible alert-success">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            <strong>Well done!</strong> Insertion OK
                        </div>
                    
        <?php
                        break;
                    case 'update':
        ?>
                        <div class="alert alert-dismissible alert-warning">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            <strong>Well done!</strong> Mise à jour OK
                        </div>
        <?php
                        break;
                    case 'delete':
        ?>
                        <div class="alert alert-dismissible alert-danger">
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                            <strong>Well done!</strong> Suppression OK
                        </div>
        <?php
                    break;
                }
            }
        ?>
        <h1>Liste des articles</h1>
        <a href="add.php" class="btn btn-primary">Nouveau</a>
        <table class="table table-condensed table-striped">
            <tr>
                <th>N°</th>
                <th>Libelle</th>
                <th>Prix</th>
                <th>Détails</th>
            </tr>
            <?php
                $i = 1;
                foreach($articles as $article){
            ?>
                <tr>
                    <td><?= $i ?></td>
                    <td><?= $article['libelle'] ?></td>
                    <td><?= $article['prix'] ?></td>
                    <td>
                        <a href="details.php?id=<?=$article['id']?>" class="btn btn-primary btn-sm">Voir plus</a>
                        <a href="update.php?id=<?=$article['id']?>" class="btn btn-warning btn-sm">Editer</a>
                        <form action="save.php" method="post" style="display:inline-block" id="target">
                            <input type="hidden" name="id" value="<?= $article['id']?>">
                            <input type="submit" name="validate" value="delete" class="btn btn-danger btn-sm">
                            <a href="categorie/add_categorie.php?id=<?=$article['id']?>" class ="btn btn-secondary btn-sm">ajouter une catégorie</a>
                        </form>
                    </td>
                </tr>
            <?php
                $i++;
                }
            ?>
        </table>
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
    <script>
        $(function(){
            $( "#target" ).on( "submit", function( event ) {
                if(confirm("Voulez vous supprimer cet enregistrement")){
                    alert("Cet enregistrement va être supprimé")
                }else{
                    event.preventDefault()
                }
            });
        })
    </script>
</body>
</html>