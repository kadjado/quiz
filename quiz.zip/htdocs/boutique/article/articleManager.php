<?php
    class ArticleManager{
        private $bd;

        public function __construct(PDO $db){
            $this->bd = $db;
        }

        public function getAll(){
            $sql = $this->bd->query('SELECT * FROM article');    
            $articles = $sql->fetchAll();
            return $articles;
        }

        public function getOne($id){
            $sql = $this->bd->prepare('SELECT * FROM article WHERE id=:id');
            $sql->execute([
                'id' => $id
            ]);

            $article = $sql->fetch(PDO::FETCH_ASSOC);
            return $article;
        }

        public function create(array $data){
            $req = $this->bd->prepare("INSERT INTO article (`libelle`, `prix`, `quantite`, `description`) VALUES (:libelle, :prix, :quantite, :description)");
            $req->execute([
                'libelle'     => $data['libelle'],
                'prix'        => $data['prix'],
                'quantite'    => $data['quantite'],
                'description' => $data['description']
            ]);
        }

        public function update(array $data){

            $req = $this->bd->prepare("UPDATE article SET `libelle`=:libelle, `prix`=:prix, `quantite`=:quantite, `description`=:description WHERE article.id =:id");
            $req->execute([
                'libelle'     => $data['libelle'],
                'prix'        => $data['prix'],
                'quantite'    => $data['quantite'],
                'description' => $data['description'],
                'id'          => $data['id']
            ]);
        }

        public function delete($id){
            $req = $this->bd->prepare("DELETE fROM article WHERE article.id =:id");
            $req->execute([
                'id' => $id
            ]);
        }

    }
?>