Cette appication contient deux interfaces : utilisateur simple et administrateur


Utilisateur simple : http://localhost/index.php

Administrateur : http://localhost/questionManager/index.php
